#include <unistd.h>
#include "typedefsTGDS.h"

#ifdef __cplusplus
extern "C" {
#endif

extern int memcpy_imm;
extern uint8 iplRom[64];
extern uint8 apuShowRom;
extern void ApuSetShowRom();

#ifdef __cplusplus
}
#endif
#include "mixrate.h"
#define ALIGNED __attribute__ ((aligned(4)))